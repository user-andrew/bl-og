# Astra Pool Website
Pool Website - www.astra-pool.com

## This is a blockchain project - I created a stake pool for Cardano, a 3rd generation cryptocurrency.


